(function () {
  if (window.__qrSnapActive) return;
  window.__qrSnapActive = true;

  const overlay = document.createElement("div");
  overlay.className = "qr-snap-overlay";

  const hint = document.createElement("div");
  hint.className = "qr-snap-hint";
  hint.textContent = "Selecciona el area del codigo QR (ESC para cancelar)";
  overlay.appendChild(hint);

  const selection = document.createElement("div");
  selection.className = "qr-snap-selection";
  selection.style.display = "none";
  overlay.appendChild(selection);

  document.body.appendChild(overlay);

  let startX = 0, startY = 0, isSelecting = false;

  const onMouseDown = (e) => {
    isSelecting = true;
    startX = e.clientX;
    startY = e.clientY;
    selection.style.display = "block";
    selection.style.left = startX + "px";
    selection.style.top = startY + "px";
    selection.style.width = "0px";
    selection.style.height = "0px";
  };

  const onMouseMove = (e) => {
    if (!isSelecting) return;
    const x = Math.min(e.clientX, startX);
    const y = Math.min(e.clientY, startY);
    const w = Math.abs(e.clientX - startX);
    const h = Math.abs(e.clientY - startY);
    selection.style.left = x + "px";
    selection.style.top = y + "px";
    selection.style.width = w + "px";
    selection.style.height = h + "px";
  };

  const onMouseUp = async (e) => {
    if (!isSelecting) return;
    isSelecting = false;

    const x = Math.min(e.clientX, startX);
    const y = Math.min(e.clientY, startY);
    const w = Math.abs(e.clientX - startX);
    const h = Math.abs(e.clientY - startY);

    if (w < 10 || h < 10) {
      cleanup();
      return;
    }

    overlay.style.display = "none";

    try {
      const dataUrl = await chrome.runtime.sendMessage({ action: "capture-tab" });
      await processCapture(dataUrl, x, y, w, h);
    } catch (err) {
      showToast("Error al capturar la pantalla: " + err.message, "", false);
      cleanup();
    }
  };

  const onKeyDown = (e) => {
    if (e.key === "Escape") {
      cleanup();
    }
  };

  overlay.addEventListener("mousedown", onMouseDown);
  overlay.addEventListener("mousemove", onMouseMove);
  overlay.addEventListener("mouseup", onMouseUp);
  document.addEventListener("keydown", onKeyDown);

  function cleanup() {
    overlay.removeEventListener("mousedown", onMouseDown);
    overlay.removeEventListener("mousemove", onMouseMove);
    overlay.removeEventListener("mouseup", onMouseUp);
    document.removeEventListener("keydown", onKeyDown);
    overlay.remove();
    window.__qrSnapActive = false;
  }

  function showToast(message, copyText, isSuccess) {
    document.querySelectorAll(".qr-snap-toast").forEach((t) => t.remove());

    const toast = document.createElement("div");
    toast.className = "qr-snap-toast";

    const text = document.createElement("span");
    text.className = "qr-snap-toast-text";
    text.textContent = message;
    toast.appendChild(text);

    if (isSuccess) {
      const copyBtn = document.createElement("button");
      copyBtn.className = "qr-snap-toast-copy";
      copyBtn.textContent = "Copiar";
      copyBtn.addEventListener("click", async (e) => {
        e.stopPropagation();
        try {
          await navigator.clipboard.writeText(copyText);
        } catch (err) {
          const ta = document.createElement("textarea");
          ta.value = copyText;
          document.body.appendChild(ta);
          ta.select();
          document.execCommand("copy");
          ta.remove();
        }
        copyBtn.textContent = "Copiado";
        copyBtn.classList.add("copied");
        setTimeout(() => {
          copyBtn.textContent = "Copiar";
          copyBtn.classList.remove("copied");
        }, 1500);
      });
      toast.appendChild(copyBtn);
    }

    const closeBtn = document.createElement("button");
    closeBtn.className = "qr-snap-toast-close";
    closeBtn.textContent = "\u00D7";
    closeBtn.title = "Cerrar";
    closeBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      toast.remove();
    });
    toast.appendChild(closeBtn);

    document.body.appendChild(toast);

    setTimeout(() => toast.remove(), isSuccess ? 8000 : 4000);
  }

  async function processCapture(dataUrl, x, y, w, h) {
    const img = new Image();
    img.src = dataUrl;

    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = reject;
    });

    const dpr = window.devicePixelRatio || 1;
    const canvas = document.createElement("canvas");
    canvas.width = w * dpr;
    canvas.height = h * dpr;

    const ctx = canvas.getContext("2d");
    ctx.drawImage(
      img,
      x * dpr, y * dpr, w * dpr, h * dpr,
      0, 0, w * dpr, h * dpr
    );

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const code = window.jsQR
      ? window.jsQR(imageData.data, imageData.width, imageData.height)
      : null;

    cleanup();

    if (code && code.data) {
      chrome.runtime.sendMessage({
        action: "qr-result",
        text: code.data,
        url: /^https?:\/\//i.test(code.data) ? code.data : null
      });

      try {
        await navigator.clipboard.writeText(code.data);
        showToast(code.data + "  (copiado al portapapeles)", code.data, true);
      } catch (err) {
        showToast(code.data, code.data, true);
      }
    } else {
      showToast("No se detecto ningun codigo QR en el area seleccionada", "", false);
    }
  }
})();