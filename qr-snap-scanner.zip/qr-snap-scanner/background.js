chrome.commands.onCommand.addListener((command) => {
  if (command === "start-scan") {
    startScan();
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "start-scan") {
    startScan();
    sendResponse({ ok: true });
    return false;
  }

  if (msg.action === "capture-tab") {
    chrome.tabs.captureVisibleTab(null, { format: "png" }, (dataUrl) => {
      if (chrome.runtime.lastError) {
        sendResponse({ error: chrome.runtime.lastError.message });
      } else {
        sendResponse(dataUrl);
      }
    });
    return true;
  }

  if (msg.action === "qr-result") {
    chrome.storage.local.get({ history: [] }, (data) => {
      const history = data.history;
      history.unshift({
        text: msg.text,
        url: msg.url || null,
        timestamp: Date.now()
      });
      chrome.storage.local.set({ history: history.slice(0, 50) });
    });
    sendResponse({ ok: true });
    return false;
  }

  if (msg.action === "clear-history") {
    chrome.storage.local.set({ history: [] }, () => {
      sendResponse({ ok: true });
    });
    return true;
  }
});

async function startScan() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab || !tab.id) {
    console.warn("[QR Snap] No hay pestana activa.");
    return;
  }

  const url = tab.url || "";
  if (
    url.startsWith("chrome://") ||
    url.startsWith("chrome-extension://") ||
    url.startsWith("edge://") ||
    url.startsWith("about:") ||
    url.startsWith("https://chrome.google.com/webstore") ||
    url.startsWith("https://chromewebstore.google.com")
  ) {
    console.warn("[QR Snap] No se puede inyectar en esta pagina:", url);
    return;
  }

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["lib/jsQR.js"]
    });
  } catch (e) {
    console.debug("[QR Snap] jsQR ya inyectado o error leve:", e.message);
  }

  try {
    await chrome.scripting.insertCSS({
      target: { tabId: tab.id },
      files: ["content/overlay.css"]
    });
  } catch (e) {
    console.error("[QR Snap] Error al insertar CSS:", e.message);
    return;
  }

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content/overlay.js"]
    });
  } catch (e) {
    console.error("[QR Snap] Error al inyectar overlay:", e.message);
  }
}

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    console.log("[QR Snap] Extension instalada correctamente");
    chrome.storage.local.set({ history: [] });
  } else if (details.reason === "update") {
    console.log("[QR Snap] Extension actualizada a la version", chrome.runtime.getManifest().version);
  }
});