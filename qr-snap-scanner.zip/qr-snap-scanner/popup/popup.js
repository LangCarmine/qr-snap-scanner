const scanBtn = document.getElementById("scanBtn");
const clearBtn = document.getElementById("clearBtn");
const historyList = document.getElementById("historyList");
const emptyMsg = document.getElementById("emptyMsg");

scanBtn.addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ action: "start-scan" });
  window.close();
});

clearBtn.addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "clear-history" }, () => {
    loadHistory();
  });
});

function loadHistory() {
  chrome.storage.local.get({ history: [] }, (data) => {
    historyList.innerHTML = "";
    if (!data.history.length) {
      emptyMsg.style.display = "block";
      return;
    }
    emptyMsg.style.display = "none";
    data.history.forEach((item) => {
      const li = document.createElement("li");

      const content = document.createElement("div");
      content.className = "history-text";
      if (item.url) {
        const a = document.createElement("a");
        a.href = item.url;
        a.target = "_blank";
        a.textContent = item.text;
        content.appendChild(a);
      } else {
        content.textContent = item.text;
      }

      const meta = document.createElement("small");
      meta.textContent = new Date(item.timestamp).toLocaleString();
      content.appendChild(meta);
      li.appendChild(content);

      const copyBtn = document.createElement("button");
      copyBtn.className = "copy-item";
      copyBtn.textContent = "Copiar";
      copyBtn.addEventListener("click", async () => {
        try {
          await navigator.clipboard.writeText(item.text);
        } catch (err) {
          const ta = document.createElement("textarea");
          ta.value = item.text;
          document.body.appendChild(ta);
          ta.select();
          document.execCommand("copy");
          ta.remove();
        }
        copyBtn.textContent = "Copiado";
        setTimeout(() => (copyBtn.textContent = "Copiar"), 1200);
      });
      li.appendChild(copyBtn);

      historyList.appendChild(li);
    });
  });
}

loadHistory();